# amazon-scrapper
A simple scrapper to get details of amazon products by amazon ASIN

> Used python3.6 for the development

```angular2html
    pip install -r requirements.txt
    python MultiThreaded.py
```